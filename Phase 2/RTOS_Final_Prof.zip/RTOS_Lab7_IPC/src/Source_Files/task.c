/* @file    task.c
 * @author  Alexander Bork
 * @date    9/16/2021
 * @brief   Creates tasks for the OS and defines functionality
 */
#include "task.h"

// Private functions for the 3 tasks
static void led_task(void *arg);
static OS_TCB LED;
static CPU_STK stack1[LED_TASK_STACK_SIZE];


static void speedSP_task(void *arg);
static OS_TCB Speed;
static CPU_STK stack2[SETPOINT_TASK_STACK_SIZE];


static void vDirec_task(void *arg);
static OS_TCB Direc;
static CPU_STK stack3[VDIREC_TASK_STACK_SIZE];


static void vMonitor_task(void *arg);
static OS_TCB Monitor;
static CPU_STK stack4[VMON_TASK_STACK_SIZE];


static void idle_task(void *arg);
static OS_TCB IDLE;
static CPU_STK stack5[IDLE_TASK_STACK_SIZE];


static volatile struct node_t * queueHead;

OS_SEM APP_Sema;
OS_FLAG_GRP LED_Flag;
OS_FLAG_GRP MONITOR_Flag;
OS_MUTEX SSDATA_MUT;
OS_MUTEX VDDATA_MUT;
OS_MUTEX FIFO_MUT;


///////////////////////////////////////////////////////////////////////////
///
/// Data structures
///
/// //////////////////////////////////////////////////////////////////////

static struct SSData appSP;
static struct VDData appVD;


/////////////////////////////////////////////////////////////////////

/*******************************************************************************
 * @brief
 *      Function to create tasks and resource managers that the OS will use
 *
 * @details
 *      There are five tasks created in the function: Speed Setpoint, Vehicle Direction,
 *      Vehicle Monitor, LED Output, and the IDLE task. And there are 3 mutexes, 2 flags,
 *      and one semaphore created as well.
 *
 * @note
 *      LED task has the highest priority, then speed setpoint, then vehicle direction, then vehicle Monitor,
 *      then IDLE.
 *      Stack size and priority are defined in task.h.
 *
 ******************************************************************************/
void task_init(void){
      RTOS_ERR err;

      // Create LED task
      OSTaskCreate(&LED,
               "led task",
               led_task,
               DEF_NULL,
               LED_TASK_PRIO,
               &stack1[0],
               (LED_TASK_STACK_SIZE / 10u),
               LED_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

      // Create button task
      OSTaskCreate(&Speed,
               "Speed Setpoint",
               speedSP_task,
               DEF_NULL,
               SETPOINT_TASK_PRIO,
               &stack2[0],
               (SETPOINT_TASK_STACK_SIZE / 10u),
               SETPOINT_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

      OSTaskCreate(&Direc,
               "Vehicle Direction",
               vDirec_task,
               DEF_NULL,
               VDIREC_TASK_PRIO,
               &stack3[0],
               (VDIREC_TASK_STACK_SIZE / 10u),
               VDIREC_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

      OSTaskCreate(&Monitor,
               "Vehicle Monitor",
               vMonitor_task,
               DEF_NULL,
               VMON_TASK_PRIO,
               &stack4[0],
               (VMON_TASK_STACK_SIZE / 10u),
               VMON_TASK_STACK_SIZE,
               0u,
               0u,
               DEF_NULL,
               (OS_OPT_TASK_STK_CLR),
               &err);
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

    //Create the idle task
   OSTaskCreate(&IDLE,
             "Idle Task",
             idle_task,
             DEF_NULL,
             IDLE_TASK_PRIO,
             &stack5[0],
             (IDLE_TASK_STACK_SIZE / 10u),
             IDLE_TASK_STACK_SIZE,
             0u,
             0u,
             DEF_NULL,
             (OS_OPT_TASK_STK_CLR),
             &err);
   EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

      ///////////////////////////////////////////////
      /// Create resources
      /// ///////////////////////////////////////////
      // Create Semaphore
      OSSemCreate(&APP_Sema,    /*   Pointer to user-allocated semaphore.          */
                  "App Semaphore",   /*   Name used for debugging.                      */
                   0,                /*   Initial count: available in this case.        */
                  &err);
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

      // Create OS Flags
      OSFlagCreate(&LED_Flag,              /*   Pointer to user-allocated event flag.         */
                   "LED Flag",             /*   Name used for debugging.                      */
                    0,                     /*   Initial flags, all cleared.                   */
                   &err);
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

      OSFlagCreate(&MONITOR_Flag,              /*   Pointer to user-allocated event flag.         */
                   "Monitor Flag",             /*   Name used for debugging.                      */
                    0,                     /*   Initial flags, all cleared.                   */
                   &err);
      EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

      // OS Mutexes
      OSMutexCreate(&SSDATA_MUT,   /*   Pointer to user-allocated mutex.                 */
                    "Speed Setpoint Mutex",  /*   Name used for debugging.                         */
                    &err);

      OSMutexCreate(&VDDATA_MUT,   /*   Pointer to user-allocated mutex.                 */
                    "Vehicle Direction Mutex",  /*   Name used for debugging.                         */
                    &err);
      OSMutexCreate(&FIFO_MUT,   /*   Pointer to user-allocated mutex.                 */
                    "Vehicle Direction Mutex",  /*   Name used for debugging.                         */
                    &err);
}

/*******************************************************************************
 * @brief
 *      Function to initialize the data structures and queue used in this lab.
 *
 * @details
 *      Initializes each of the elements of the data structures to be 0.
 *
 * @note
 *      Only called once via an app.c function
 *
 ******************************************************************************/
void queue_init(void){
    queueHead = create_queue();
    appSP.currSpd = 0;
    appSP.spdInc = 0;
    appSP.spdDec = 0;

    appVD.leftCnt = 0;
    appVD.rightCnt = 0;
    appVD.currDirec = 0;
    appVD.sameDirecCnt = 0;
}


/*******************************************************************************
 * @brief
 *      Function that defines the LED task
 *
 * @details
 *      The LED pins are initialized before the while loop. And the LED_task will update
 *      the LEDs based off of violations sent to it via a flag post from the vehicle monitor
 *      task.
 *
 * @note
 *      This task will stay blocked as long as it does not have a flag posted to it via
 *      LED_Flag.
 *
 ******************************************************************************/
static void led_task(void *arg){
    // Set LED ports to be standard output drive with default off (cleared)
    GPIO_DriveStrengthSet(LED0_port, gpioDriveStrengthStrongAlternateStrong);
    //  GPIO_DriveStrengthSet(LED0_port, gpioDriveStrengthWeakAlternateWeak);
    GPIO_PinModeSet(LED0_port, LED0_pin, gpioModePushPull, LED0_default);

    GPIO_DriveStrengthSet(LED1_port, gpioDriveStrengthStrongAlternateStrong);
    //  GPIO_DriveStrengthSet(LED1_port, gpioDriveStrengthWeakAlternateWeak);
    GPIO_PinModeSet(LED1_port, LED1_pin, gpioModePushPull, LED1_default);
    // Drive the leds based on input
    RTOS_ERR  err;
    OS_FLAGS  flags;
    while(1){
        flags = OSFlagPend(&LED_Flag,
                             LED_FLAG_ALL,
                             0,
                             OS_OPT_PEND_FLAG_SET_ANY |
                             OS_OPT_PEND_BLOCKING |
                             OS_OPT_PEND_FLAG_CONSUME,
                             DEF_NULL,
                             &err);
        if(flags == NO_VIOS){
            GPIO_PinOutClear(LED0_port, LED0_pin);
            GPIO_PinOutClear(LED1_port, LED1_pin);
        }
        else if(flags == SPEED_VIO){
            GPIO_PinOutSet(LED0_port, LED0_pin);
            GPIO_PinOutClear(LED1_port, LED1_pin);
        }
        else if(flags == COLL_ALERT){
            GPIO_PinOutClear(LED0_port, LED0_pin);
            GPIO_PinOutSet(LED1_port, LED1_pin);
        }
        else{
            GPIO_PinOutSet(LED0_port, LED0_pin);
            GPIO_PinOutSet(LED1_port, LED1_pin);
        }
    }
}


/*******************************************************************************
 * @brief
 *      Function that defines the Speed Setpoint task
 *
 * @details
 *      The push button pins are initialized before the while loop, and so is the button state
 *      machine. The task will increment/decrement the speed and iterations within the
 *      application Speed Setpoint data structure and post via a flag to the Vehicle Monitor task.
 *
 * @note
 *      This task is only unblocked when receiving a semaphore post from the GPIO interrupt handlers.
 *
 ******************************************************************************/
static void speedSP_task(void *arg){
    GPIO_PinModeSet(BSP_GPIO_PB0_PORT, BSP_GPIO_PB0_PIN, gpioModeInput, false); // Init the PB gpio pins
    GPIO_PinModeSet(BSP_GPIO_PB1_PORT, BSP_GPIO_PB1_PIN, gpioModeInput, false);
    initButtonSM();
    RTOS_ERR err;
    OS_SEM_CTR  ctr;
    uint8_t fifoMsg;
    OS_FLAGS flag;
    while(1){
        ctr = OSSemPend(&APP_Sema,        /* Pointer to user-allocated semaphore.    */
                        0,
                        OS_OPT_PEND_BLOCKING, /* Task will block.                        */
                        DEF_NULL,             /* Timestamp is not used.                  */
                        &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

        OSMutexPend(&FIFO_MUT,            // Mutex for the FIFO
                    0,
                    OS_OPT_PEND_BLOCKING,
                    DEF_NULL,
                    &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

        fifoMsg = peek(&queueHead);
        pop(&queueHead);

        OSMutexPost(&FIFO_MUT,         // Release mutex on FIFO
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                     &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.


        OSMutexPend(&SSDATA_MUT,            // Mutex for the Speed Setpoint data structure
                    0,
                    OS_OPT_PEND_BLOCKING,
                    DEF_NULL,
                    &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

        if(fifoMsg == button0){
            appSP.currSpd += 5;
            appSP.spdInc += 1;
            flag = OSFlagPost(&MONITOR_Flag,             /*   Pointer to user-allocated event flag.    */
                            speedFlag,
                            OS_OPT_POST_FLAG_SET,
                            &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
            //post event to Vehicle Monitor task
        }
        else if(fifoMsg == button1){
            if(appSP.currSpd >= 5){
                appSP.currSpd -= 5;
                appSP.spdDec += 1;
                flag = OSFlagPost(&MONITOR_Flag,             /*   Pointer to user-allocated event flag.    */
                                    speedFlag,
                                    OS_OPT_POST_FLAG_SET,
                                    &err);
                EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
            }
        }
        OSMutexPost(&SSDATA_MUT,         // Release mutex on speed setpoint data structure
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                     &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

    }
    // Read the buttons
}


/*******************************************************************************
 * @brief
 *      Function that defines the vehicle direction task
 *
 * @details
 *      The capsense pads are initialized before the while loop. Within the while loop
 *      there is an OS delay. The capsense pads are "sensed", the task acquires a mutex lock
 *      on our application Vehicle Direction data structure, and we update the
 *      structure with the new values. The mutex is released, then a post is made to the vehicle
 *      monitor task.
 *
 * @note
 *      An OS delay of 100ms is used. This function will occur 5 times in SystemView
 *      as there is a 10ms OSDelay in each of the getPressed function calls.
 *
 ******************************************************************************/
static void vDirec_task(void *arg)
{
    uint8_t CAP_STATE = 3; // Initialize the state of the Cap sensors.
    CAPSENSE_Init(); // Initialize the capsense peripherals
    RTOS_ERR    err;
    OS_SEM_CTR  ctr;
    OS_FLAGS flag;
    uint8_t prevDirec = 0;
    while(1){
        //EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        OSTimeDly(100,              /*   Delay the task for 100 OS Ticks.         */
                  OS_OPT_TIME_DLY,  /*   Delay is relative to current time.       */
                  &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));


        CAPSENSE_Sense();       // Sense the capsense
        CAP_STATE = (CAPSENSE_getPressed(CHANNEL3) << 3);
        CAP_STATE |= (CAPSENSE_getPressed(CHANNEL2) << 2);
        CAP_STATE |= (CAPSENSE_getPressed(CHANNEL1) << 1);
        CAP_STATE |= CAPSENSE_getPressed(CHANNEL0);

        OSMutexPend(&VDDATA_MUT,            // Mutex for the Speed Setpoint data structure
                    0,
                    OS_OPT_PEND_BLOCKING,
                    DEF_NULL,
                    &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

        if(CAP_STATE == 0b1){
            appVD.currDirec = hardLeft;
            appVD.leftCnt += 1;
        }
        else if(CAP_STATE == 0b10){
            appVD.currDirec = softLeft;
            appVD.leftCnt += 1;
        }
        else if(CAP_STATE == 0b100){
            appVD.currDirec = softRight;
            appVD.rightCnt += 1;
        }
        else if(CAP_STATE == 0b1000){
            appVD.currDirec = hardRight;
            appVD.rightCnt += 1;
        }
        else{
            appVD.currDirec = straight;
        }


        if(appVD.currDirec == prevDirec){
            appVD.sameDirecCnt += 1;
        }
        else{
            appVD.sameDirecCnt = 0;
            prevDirec = appVD.currDirec;
        }

        OSMutexPost(&VDDATA_MUT,         // Release mutex on speed setpoint data structure
                     OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                     &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.


        flag = OSFlagPost(&MONITOR_Flag,             /*   Pointer to user-allocated event flag.    */
                            directionFlag,
                            OS_OPT_POST_FLAG_SET,
                            &err);
        EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
    }
}


/*******************************************************************************
 * @brief
 *      Function that defines the vehicle monitor task
 *
 * @details
 *      Local variables are initialized before entering the while loop. This task pends on
 *      flags from either the speed setpoint or the vehicle direction tasks. After receiving
 *      a flag from either of those tasks, it will acquire a mutex lock on the appSP or appVD
 *      data structures and read the variables from it. It will then calculate any violations
 *      that there might be.
 *
 * @note
 *      This task stays blocked unless it receives a flag post on the MONITOR_Flag OS_FLAG.
 *
 ******************************************************************************/


static void vMonitor_task(void *arg){
    RTOS_ERR    err;
    OS_FLAGS flags;

    uint8_t direc = 0;
    uint8_t speed = 0;
    uint8_t direcCnt = 0;

    uint8_t speedVio = 0;
    uint8_t collAlert = 0;
    while(1){
        flags = OSFlagPend(&MONITOR_Flag,                /*   Pointer to user-allocated event flag. */
                            APP_FLAG_ALL,             /*   Flag bitmask to match.                */
                            0,                      /*   Wait for 100 OS Ticks maximum.        */
                            OS_OPT_PEND_FLAG_SET_ANY |/*   Wait until all flags are set and      */
                            OS_OPT_PEND_BLOCKING     |/*    task will block and                  */
                            OS_OPT_PEND_FLAG_CONSUME, /*    function will clear the flags.       */
                            DEF_NULL,                 /*   Timestamp is not used.                */
                            &err);
        if(flags == speedFlag){
            OSMutexPend(&SSDATA_MUT,            // Mutex for the Speed Setpoint data structure
                        0,
                        OS_OPT_PEND_BLOCKING,
                        DEF_NULL,
                        &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

            speed = appSP.currSpd;

            OSMutexPost(&SSDATA_MUT,         // Release mutex on speed setpoint data structure
                         OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                         &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.
        }
        else{
            OSMutexPend(&VDDATA_MUT,            // Mutex for the Speed Setpoint data structure
                        0,
                        OS_OPT_PEND_BLOCKING,
                        DEF_NULL,
                        &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));

            direc = appVD.currDirec;
            direcCnt = appVD.sameDirecCnt;

            OSMutexPost(&VDDATA_MUT,         // Release mutex on speed setpoint data structure
                         OS_OPT_POST_1,     /*   Only wake up highest-priority task.      */
                         &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }

        // Check for violations/alerts!!!
        if((speed >= 75) || ((speed >= 45) && (direc != 0))){
            speedVio = 1;
        }
        else{
            speedVio = 0;
        }
        if((direc != 0) && (direcCnt >= 50)){
            collAlert = 1;
        }
        else{
            collAlert = 0;
        }

        // If the alert for the LED is not the same as last time
        if(speedVio && collAlert){
            flags = OSFlagPost(&LED_Flag,             /*   Pointer to user-allocated event flag.    */
                                BOTH_VIOS,
                                OS_OPT_POST_FLAG_SET,
                                &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }
        else if(speedVio){
            flags = OSFlagPost(&LED_Flag,             /*   Pointer to user-allocated event flag.    */
                                SPEED_VIO,
                                OS_OPT_POST_FLAG_SET,
                                &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }
        else if(collAlert){
            flags = OSFlagPost(&LED_Flag,             /*   Pointer to user-allocated event flag.    */
                                COLL_ALERT,
                                OS_OPT_POST_FLAG_SET,
                                &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }
        else{
            flags = OSFlagPost(&LED_Flag,             /*   Pointer to user-allocated event flag.    */
                                NO_VIOS,
                                OS_OPT_POST_FLAG_SET,
                                &err);
            EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        }
    }
}



/***************************************************************************//**
 * @brief
 *      Interrupt Handler for even GPIO interrupts
 *
 * @details
 *      All even interrupts will be cleared from the GPIO Int flag register.
 *      This function will then request the state of pushButton0 and update the
 *      global variable within pushbutton.c. Both negedge and posedge interrupts
 *      are enabled.
 *
 * @note
 *      This interrupt is trigger for PB0, as it is on PortF - pin 6
 *
 *
 ******************************************************************************/
void GPIO_EVEN_IRQHandler(void){
    // Clear all even pin interrupt flags
    GPIO_IntClear(EVEN_GPIO_IRPT);
    RTOS_ERR err;
    OS_SEM_CTR  ctr;
    update_button0State();
    update_button1State();
    uint8_t buttonSt = (get_buttonState1() << 1) | get_buttonState0();
    if(buttonSt == 3){
        push(&queueHead, buttonNone);
    }
    else if(buttonSt == 2){
        push(&queueHead, button0);
    }
    else if(buttonSt == 1){
        push(&queueHead, button1);
    }
    else{
        push(&queueHead, buttonBoth);
    }
    ctr = OSSemPost(&APP_Sema,    /* Pointer to user-allocated semaphore.    */
                    OS_OPT_POST_ALL,    /* Only wake up highest-priority task.     */
                    &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

}


/***************************************************************************//**
 * @brief
 *      Interrupt Handler for odd GPIO interrupts
 *
 * @details
 *      All odd interrupts will be cleared from the GPIO Int flag register.
 *      This function will then request the state of pushButton1 and update the
 *      global variable within pushbutton.c. Only the negedge interrupts
 *      are enabled and valid.
 *
 * @note
 *      This interrupt is trigger for PB1, as it is on PortF - pin 7
 *
 *
 ******************************************************************************/
void GPIO_ODD_IRQHandler(void){
    // Clear all even pin interrupt flags
    GPIO_IntClear(ODD_GPIO_IRPT);
    RTOS_ERR err;
    OS_SEM_CTR  ctr;
    update_button0State();
    update_button1State();
    uint8_t buttonSt = (get_buttonState1() << 1) | get_buttonState0();
    if(buttonSt == 3){
        push(&queueHead, buttonNone);
    }
    else if(buttonSt == 2){
        push(&queueHead, button0);
    }
    else if(buttonSt == 1){
        push(&queueHead, button1);
    }
    else{
        push(&queueHead, buttonBoth);
    }

    ctr = OSSemPost(&APP_Sema,    /* Pointer to user-allocated semaphore.    */
                    OS_OPT_POST_ALL,    /* Only wake up highest-priority task.     */
                    &err);
    EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE)); // Check that there are no errors in creating the task.

}



/*******************************************************************************
 * @brief
 *      Function that defines the idle task
 *
 * @details
 *      This function only keeps the board in energy mode 1.
 *
 * @note
 *      An OS delay of 5ms is used.
 *
 ******************************************************************************/
static void idle_task(void *arg)
{
//    RTOS_ERR err;
    // Read the capsensor
    while(1){
        //EFM_ASSERT((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE));
        EMU_EnterEM1(); // Go into energy mode 1
    }
}


